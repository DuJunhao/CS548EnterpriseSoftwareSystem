package edu.stevens.cs548.clinic.service.ejb;

import javax.ejb.Local;

@Local
public interface IPatientServiceLocal extends IPatientService {

}
